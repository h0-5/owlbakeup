propertyGetters = {
	object = {
		model = getElementModel,
		doublesided = function(element)
			if isElementDoubleSided then
				return isElementDoubleSided(element) and "true" or "false"
			else
				return getElementData(element,"doublesided")=="true" and "true" or "false"
			end
		end,
		scale = getObjectScale,
		breakable = function(element) return tostring(isObjectBreakable(element)) end,
		collisions = function(element)
			local collisions = getElementData(element, "collisions")
			if collisions == "true" or collisions == false then
				return "true"
			else
				return "false"
			end
		end,
		moveSpeed = function(element)
			local time = getElementData(element, "moveSpeed")
			if time == nil or time == false then
				return 1
			else
				return time
			end
		end,
		moveDelay = function(element)
			local delay = getElementData(element, "moveDelay")
			if delay == nil or delay == false then
				return 0
			else
				return delay
			end
		end,
		moveX = function(element)
			local offsetX = getElementData(element, "moveX")
			if offsetX == nil or offsetX == false then
				return 0
			else
				return offsetX
			end
		end,
		moveY = function(element)
			local offsetY = getElementData(element, "moveY")
			if offsetY == nil or offsetY == false then
				return 0
			else
				return offsetY
			end
		end,
		moveZ = function(element)
			local offsetZ = getElementData(element, "moveZ")
			if offsetZ == nil or offsetZ == false then
				return 0
			else
				return offsetZ
			end
		end
	},
	ped = {
		model = getElementModel,
		rotZ = getPedRotation,
		health = getElementHealth,
		armor = getPedArmor,
		collisions = function(element)
			local collisions = getElementData(element, "collisions")
			if collisions == "true" or collisions == false then
				return "true"
			else
				return "false"
			end
		end
	},
	vehicle = {
		model = getElementModel,
		color1 = function(element)
			local vehCol = {getVehicleColor(element, true)}
			return {vehCol[1], vehCol[2], vehCol[3]}
		end,
		color2 = function(element)
			local vehCol = {getVehicleColor(element, true)}
			return {vehCol[4], vehCol[5], vehCol[6]}
		end,
		color3 = function(element)
			local vehCol = {getVehicleColor(element, true)}
			return {vehCol[7], vehCol[8], vehCol[9]}
		end,
		color4 = function(element)
			local vehCol = {getVehicleColor(element, true)}
			return {vehCol[10], vehCol[11], vehCol[12]}
		end,
		upgrades = getVehicleUpgrades,
		plate = getVehiclePlateText,
		sirens = function(vehicle)
			return getVehicleSirensOn(vehicle) and "true" or "false"
		end,
		health = getElementHealth,
		paintjob = function(vehicle) return tostring(getVehiclePaintjob(vehicle)) end,
		landingGearDown = function(element) return tostring(getVehicleLandingGearDown(element)) end,
		collisions = function(element)
			local collisions = getElementData(element, "collisions")
			if collisions == "true" or collisions == false then
				return "true"
			else
				return "false"
			end
		end
	},
	marker = {
		type = getMarkerType,
		size = getMarkerSize,
		color = function(element)
			return {getMarkerColor(element)}
		end,
	},
	pickup = {
		type = function(element)
			local pType = getPickupType(element)
			if pType == 0 then
				return "health"
			elseif pType == 1 then
				return "armor"
			elseif pType == 2 then
				return getPickupWeapon(element)
			elseif pType == 3 then
				return "Custom"
			end
		end,
	},
	radararea = {
		sizeX = function(element)
			local sizeX = getRadarAreaSize(element)
			return sizeX
		end,
		sizeY = function(element)
			local _,sizeY = getRadarAreaSize(element)
			return sizeY
		end,
		posX = function(element)
			local posX = getElementPosition(element)
			return posX
		end,
		posY = function(element)
			local _,posY = getElementPosition(element)
			return posY
		end,
		color = function(element)
			return {getRadarAreaColor(element)}
		end,
	},
	blip = {
		color = function(element)
			return {getBlipColor(element)}
		end,
		size = getBlipSize,
		icon = getBlipIcon,
	},
	water = {
		sizeX = function(element)
			local x1 = getWaterVertexPosition ( element, 1 )
			local x2 = getWaterVertexPosition ( element, 2 )
			return x2 - x1
		end,
		sizeY = function(element)
			local _,y1 = getWaterVertexPosition ( element, 2 )
			local _,y2 = getWaterVertexPosition ( element, 3 )
			return y2 - y1
		end,
	}
}

propertySetters = {
	object = {
		model = function(element, model)
			if model then return setElementModel(element, model)
			else return false end
		end,
		doublesided = function(element,bon)
			if setElementDoubleSided then
				return setElementDoubleSided(element,bon=="true")
			else
				return setElementData(element,"doublesided",bon=="true" and "true" or "false")
			end
		end,
		scale = function(element, scale)
			if ( scale ) then
				return setObjectScale(element, scale)
			end
			return false
		end,
		breakable = function(element, breakable)
			return setObjectBreakable(element, breakable == "true")
		end
	},
	ped = {
		model = function(element, model)
			if model then return setElementModel(element, model)
			else return false end
		end,
		rotZ = function(element, rot)
			if tonumber(rot) then return setElementRotation(element, 0, 0, rot)
			else return false end
		end,
		health = setElementHealth,
		armor = setPedArmor,
		collisions = function(element, state)
			return setElementCollisionsEnabled(element, state == "true")
		end
	},
	vehicle = {
		model = function(element, model)
			if model then return setElementModel(element, model)
			else return false end
		end,
		color1 = function(element, colorsTable)
			if colorsTable then
				colorsTable = {getColorFromString(colorsTable)}
				local otherColors = {getVehicleColor(element, true)}
				return setVehicleColor(element, colorsTable[1], colorsTable[2], colorsTable[3], otherColors[4], otherColors[5], otherColors[6], otherColors[7], otherColors[8], otherColors[9], otherColors[10], otherColors[11], otherColors[12])
			else
				return false
			end
		end,
		color2 = function(element, colorsTable)
			if colorsTable then
				colorsTable = {getColorFromString(colorsTable)}
				local otherColors = {getVehicleColor(element, true)}
				return setVehicleColor(element, otherColors[1], otherColors[2], otherColors[3], colorsTable[1], colorsTable[2], colorsTable[3], otherColors[7], otherColors[8], otherColors[9], otherColors[10], otherColors[11], otherColors[12])
			else
				return false
			end
		end,
		color3 = function(element, colorsTable)
			if colorsTable then
				colorsTable = {getColorFromString(colorsTable)}
				local otherColors = {getVehicleColor(element, true)}
				return setVehicleColor(element, colorsTable[1], colorsTable[2], colorsTable[3], otherColors[4], otherColors[5], otherColors[6], colorsTable[1], colorsTable[2], colorsTable[3], otherColors[10], otherColors[11], otherColors[12])
			else
				return false
			end
		end,
		color4 = function(element, colorsTable)
			if colorsTable then
				colorsTable = {getColorFromString(colorsTable)}
				local otherColors = {getVehicleColor(element, true)}
				return setVehicleColor(element, colorsTable[1], colorsTable[2], colorsTable[3], otherColors[4], otherColors[5], otherColors[6], otherColors[7], otherColors[8], otherColors[9], colorsTable[1], colorsTable[2], colorsTable[3])
			else
				return false
			end
		end,
		upgrades = function(element, upgradesTable)
			if upgradesTable then
				for slot = 0, 16 do
					local upgrade = getVehicleUpgradeOnSlot ( element, slot )
					if upgrade then
						removeVehicleUpgrade( element, upgrade )
					end
				end
				for i, upgrade in ipairs(upgradesTable) do
					addVehicleUpgrade(element, upgrade)
				end
				return true
			else
				return false
			end
		end,
		paintjob = setVehiclePaintjob,
		plate = setVehiclePlateText,
		sirens = function(vehicle, bon)
			return setVehicleSirensOn(vehicle, bon == "true" and true or false)
		end,
		health = setElementHealth,
		landingGearDown = function(element, state)
			return setVehicleLandingGearDown(element, state == "true")
		end,
		collisions = function(element, state)
			return setElementCollisionsEnabled(element, state == "true")
		end
	},
	marker = {
		type = function(element, markerType)
			if markerType then return setMarkerType(element, markerType)
			else return false end
		end,
		size = function(element, markerSize)
			if markerSize then return setMarkerSize(element, markerSize)
			else return false end
		end,
		color = function(element, color)
			if color then return setMarkerColor(element, getColorFromString(color))
			else return false end
		end,
	},
	pickup = {
		type = function(element, pType)
			if pType then
				local nType
				local amount = getPickupAmount(element)
				if pType == "health" then
					return setPickupType(element, 0, amount)
				elseif pType == "armor" then
					return setPickupType(element, 1, amount)
				elseif pType == "custom" then
					return setPickupType(element, 3)
				else
					return setPickupType(element, 2, pType, amount)
				end
			else
				return false
			end
		end,
	},
	radararea = {
		sizeX = function(element, sizeX)
			if sizeX then
				local _, currentY = getRadarAreaSize(element)
				return setRadarAreaSize(element, sizeX, currentY)
			else
				return false
			end
		end,
		sizeY = function(element, sizeY)
			if sizeY then
				local currentX = getRadarAreaSize(element)
				return setRadarAreaSize(element, currentX, sizeY)
			else
				return false
			end
		end,
		posX = function(element, posX)
			if posX then
				local _, currentY = getElementPosition(element)
				return setElementPosition(element, posX, currentY, 0)
			else
				return false
			end
		end,
		posY = function(element, posY)
			if posY then
				local currentX = getElementPosition(element)
				return setElementPosition(element, currentX, posY, 0)
			else
				return false
			end
		end,
		color = function(element, colorstr)
			if colorstr then
				local r, g, b, a = getColorFromString(colorstr)
				return setRadarAreaColor(element, r, g, b, a)
			else
				return false
			end
		end,
	},
	blip = {
		color = function(element, colorstr)
			if colorstr then
				local r, g, b, a = getColorFromString(colorstr)
				return setBlipColor(element, r, g, b, a)
			else
				return false
			end
		end,
		size = function(element, blipSize)
			if blipSize then return setBlipSize(element, blipSize)
			else return false end
		end,
		icon = function(element, blipIcon)
			if blipIcon then return setBlipIcon(element, blipIcon)
			else return false end
		end,
	},
}
